<?php
require_once __DIR__ . '/functions.php';
$lang = set_language();
$dir = dir_attr();
?>
<!doctype html>
<html lang="<?= $lang ?>" dir="<?= $dir ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= esc(APP_NAME) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    body { background:#f7f7fb; }
    .card { border:0; border-radius: 1rem; box-shadow: 0 6px 18px rgba(0,0,0,.06); }
    .rtl .form-control, .rtl .btn { text-align:right; }
  </style>
</head>
<body class="<?= $dir==='rtl' ? 'rtl' : '' ?>">
<nav class="navbar navbar-expand-lg bg-white border-bottom">
  <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php"><?= esc(APP_NAME) ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="tickets.php"><?= t('tickets') ?></a></li>
          <li class="nav-item"><a class="nav-link" href="ticket_new.php"><?= t('new_ticket') ?></a></li>
          <?php if (in_array(user()['role'], ['admin','agent'])): ?>
            <li class="nav-item"><a class="nav-link" href="admin.php"><?= t('admin_panel') ?></a></li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#"><?= $lang==='ar'?'العربية':'English' ?></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
            <li><a class="dropdown-item" href="?lang=en">English</a></li>
          </ul>
        </li>
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="logout.php"><?= t('logout') ?></a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="index.php"><?= t('login') ?></a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container my-4">
