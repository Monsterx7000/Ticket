<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/functions.php';
require_login(); check_csrf();

$id = (int)($_GET['id'] ?? 0);
$role = user()['role'];
// Load ticket
$stmt = $pdo->prepare("SELECT t.*, u.name owner_name FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?");
$stmt->execute([$id]);
$ticket = $stmt->fetch();
if (!$ticket) { http_response_code(404); die('Not Found'); }
if (!in_array($role, ['admin','agent']) && $ticket['user_id'] != user()['id']) {
    http_response_code(403); die('Forbidden');
}

// Handle actions
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (isset($_POST['reply'])) {
        $content = trim($_POST['content'] ?? '');
        $file = upload_file('attachment');
        if ($content !== '') {
            $stmt = $pdo->prepare("INSERT INTO ticket_replies (ticket_id,user_id,content,attachment,created_at) VALUES (?,?,?,?,NOW())");
            $stmt->execute([$id, user()['id'], $content, $file]);
            $pdo->prepare("UPDATE tickets SET updated_at=NOW() WHERE id=?")->execute([$id]);
            header("Location: ticket_view.php?id=".$id); exit;
        }
    } elseif (isset($_POST['status']) && in_array($_POST['status'], ['open','pending','closed'])) {
        require_role(['admin','agent']);
        $pdo->prepare("UPDATE tickets SET status=?, updated_at=NOW() WHERE id=?")->execute([$_POST['status'],$id]);
        header("Location: ticket_view.php?id=".$id); exit;
    } elseif (isset($_POST['assign_to'])) {
        require_role(['admin','agent']);
        $to = (int)$_POST['assign_to'];
        $pdo->prepare("UPDATE tickets SET assigned_to=?, updated_at=NOW() WHERE id=?")->execute([$to,$id]);
        header("Location: ticket_view.php?id=".$id); exit;
    }
}

// Load replies
$replies = $pdo->prepare("SELECT r.*, u.name uname FROM ticket_replies r JOIN users u ON u.id=r.user_id WHERE ticket_id=? ORDER BY r.id ASC");
$replies->execute([$id]);
$replies = $replies->fetchAll();
// Agents list
$agents = $pdo->query("SELECT id,name FROM users WHERE role IN ('agent','admin') ORDER BY name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="row">
  <div class="col-lg-8">
    <div class="card p-3 mb-3">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <h4>#<?= (int)$ticket['id'] ?> - <?= esc($ticket['subject']) ?></h4>
          <div class="text-muted small"><?= t('owner') ?>: <?= esc($ticket['owner_name']) ?> · <?= t('category') ?>: <?= esc($ticket['category']) ?> · <?= t('priority') ?>: <?= esc($ticket['priority']) ?></div>
        </div>
        <div>
          <span class="badge bg-<?= $ticket['status']==='open'?'success':($ticket['status']=='pending'?'warning':'secondary') ?>"><?= t($ticket['status']) ?></span>
        </div>
      </div>
      <?php if ($ticket['attachment']): ?>
        <div class="mt-2"><a target="_blank" href="../uploads/<?= esc($ticket['attachment']) ?>"><?= t('attachment') ?></a></div>
      <?php endif; ?>
      <p class="mt-3"><?= nl2br(esc($ticket['message'])) ?></p>
    </div>

    <div class="card p-3">
      <h5 class="mb-3"><?= t('reply') ?></h5>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <div class="mb-3">
          <textarea class="form-control" rows="4" name="content" required></textarea>
        </div>
        <div class="mb-3">
          <input class="form-control" type="file" name="attachment">
        </div>
        <button class="btn btn-primary" name="reply" value="1"><?= t('submit') ?></button>
      </form>
    </div>

    <div class="card p-3 mt-3">
      <h6 class="mb-3"><?= t('created') ?> / <?= t('last_update') ?></h6>
      <div class="text-muted small"><?= esc($ticket['created_at']) ?> · <?= esc($ticket['updated_at']) ?></div>
    </div>
  </div>
  <div class="col-lg-4">
    <?php if (in_array($role, ['admin','agent'])): ?>
    <div class="card p-3 mb-3">
      <h6><?= t('change_status') ?></h6>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <select class="form-select" name="status">
          <option value="open" <?= $ticket['status']==='open'?'selected':'' ?>><?= t('open') ?></option>
          <option value="pending" <?= $ticket['status']==='pending'?'selected':'' ?>><?= t('pending') ?></option>
          <option value="closed" <?= $ticket['status']==='closed'?'selected':'' ?>><?= t('closed') ?></option>
        </select>
        <button class="btn btn-secondary mt-2"><?= t('save') ?></button>
      </form>
    </div>
    <div class="card p-3">
      <h6><?= t('assign_to') ?></h6>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <select class="form-select" name="assign_to">
          <option value="0">-</option>
          <?php foreach ($agents as $a): ?>
            <option value="<?= (int)$a['id'] ?>" <?= $ticket['assigned_to']==$a['id']?'selected':'' ?>><?= esc($a['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <button class="btn btn-secondary mt-2"><?= t('save') ?></button>
      </form>
    </div>
    <?php endif; ?>
    <div class="card p-3 mt-3">
      <h6><?= t('add_reply') ?></h6>
      <?php foreach ($replies as $r): ?>
        <div class="border rounded p-2 mb-2">
          <div class="small text-muted"><?= esc($r['uname']) ?> · <?= esc($r['created_at']) ?></div>
          <div><?= nl2br(esc($r['content'])) ?></div>
          <?php if ($r['attachment']): ?>
            <div><a target="_blank" href="../uploads/<?= esc($r['attachment']) ?>"><?= t('attachment') ?></a></div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
