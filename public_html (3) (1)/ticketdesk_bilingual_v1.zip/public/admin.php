<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/functions.php';
require_login(); require_role(['admin','agent']); check_csrf();

$msg = '';
// Simple user role update
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['uid'], $_POST['role'])) {
    $uid = (int)$_POST['uid'];
    $role = $_POST['role'];
    if (in_array($role, ['user','agent','admin'])) {
        $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$uid]);
        $msg = t('updated_success');
    }
}

$users = $pdo->query("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 200")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="card p-3">
  <h4 class="mb-3"><?= t('admin_panel') ?></h4>
  <?php if ($msg): ?><div class="alert alert-success"><?= esc($msg) ?></div><?php endif; ?>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>#</th><th><?= t('name') ?></th><th><?= t('email') ?></th><th><?= t('role') ?></th><th><?= t('created_at') ?></th><th><?= t('actions') ?></th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= (int)$u['id'] ?></td>
          <td><?= esc($u['name']) ?></td>
          <td><?= esc($u['email']) ?></td>
          <td><span class="badge bg-secondary"><?= esc($u['role']) ?></span></td>
          <td><?= esc($u['created_at']) ?></td>
          <td>
            <form class="d-flex gap-2" method="post">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="uid" value="<?= (int)$u['id'] ?>">
              <select class="form-select form-select-sm" name="role">
                <option <?= $u['role']==='user'?'selected':'' ?> value="user"><?= t('user') ?></option>
                <option <?= $u['role']==='agent'?'selected':'' ?> value="agent"><?= t('agent') ?></option>
                <option <?= $u['role']==='admin'?'selected':'' ?> value="admin"><?= t('admin') ?></option>
              </select>
              <button class="btn btn-sm btn-primary"><?= t('save') ?></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
