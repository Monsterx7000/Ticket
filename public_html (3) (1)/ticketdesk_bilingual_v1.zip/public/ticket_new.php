<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../includes/functions.php';
require_login(); check_csrf();

$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $category = trim($_POST['category'] ?? 'General');
    $priority = trim($_POST['priority'] ?? 'Normal');
    $file = upload_file('attachment');
    $stmt = $pdo->prepare("INSERT INTO tickets (user_id,subject,message,category,priority,status,attachment,created_at,updated_at)
                           VALUES (?,?,?,?,?,'open',?,NOW(),NOW())");
    $stmt->execute([user()['id'],$subject,$message,$category,$priority,$file]);
    $id = $pdo->lastInsertId();
    header("Location: ticket_view.php?id=".$id);
    exit;
}

include __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="card p-4">
      <h4 class="mb-3"><?= t('new_ticket') ?></h4>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <div class="mb-3">
          <label class="form-label"><?= t('subject') ?></label>
          <input class="form-control" required name="subject">
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('category') ?></label>
          <input class="form-control" name="category" value="General">
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('priority') ?></label>
          <select class="form-select" name="priority">
            <option>Low</option><option selected>Normal</option><option>High</option><option>Urgent</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('message') ?></label>
          <textarea class="form-control" rows="6" required name="message"></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('attachment') ?></label>
          <input class="form-control" type="file" name="attachment">
        </div>
        <button class="btn btn-primary"><?= t('create') ?></button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
